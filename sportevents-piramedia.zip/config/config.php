<?php
/**
 * Configurazioni generali dell'applicazione
 */

// Detect environment
$isPiramedia = isset($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'], 'piramedia.it') !== false;
$isRender = isset($_ENV['RENDER']) || isset($_ENV['RENDER_EXTERNAL_URL']);
$isLocalhost = !$isPiramedia && !$isRender;

if ($isPiramedia) {
    define('BASE_URL', 'https://biglietteria.piramedia.it');
    define('ENVIRONMENT', 'production');
} elseif ($isRender) {
    define('BASE_URL', $_ENV['RENDER_EXTERNAL_URL'] ?? 'https://your-app.onrender.com');
    define('ENVIRONMENT', 'staging');
} else {
    define('BASE_URL', 'http://localhost:8001');
    define('ENVIRONMENT', 'development');
}

define('SITE_NAME', 'SportEvents');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Configurazioni email
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('FROM_EMAIL', 'noreply@sportevents.com');
define('FROM_NAME', 'SportEvents');

// Configurazioni PayPal
define('PAYPAL_CLIENT_ID', '');
define('PAYPAL_CLIENT_SECRET', '');
define('PAYPAL_MODE', 'sandbox'); // sandbox o live

// Sessioni
session_start();

// Timezone
date_default_timezone_set('Europe/Rome');

// Autoload delle classi
spl_autoload_register(function ($class) {
    $paths = [
        __DIR__ . '/../app/models/',
        __DIR__ . '/../app/controllers/',
    ];
    
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            break;
        }
    }
});
?>
